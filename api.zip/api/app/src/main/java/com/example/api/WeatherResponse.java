package com.example.api;

import com.google.gson.annotations.SerializedName;

public class WeatherResponse {
    @SerializedName("main")
    private MainInfo mainInfo;

    public MainInfo getMainInfo() {
        return mainInfo;
    }

    public static class MainInfo {
        @SerializedName("temp")
        private float temperature;

        public float getTemperature() {
            return temperature;
        }
    }
}
