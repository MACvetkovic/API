package com.example.api;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private EditText cityEditText;
    private TextView temperatureTextView;

    private static final String BASE_URL = "https://api.openweathermap.org/";
    private static final String API_KEY = "f2789613526a4af580524b9194a3b79a"; // Zamijenite s vašim API ključem

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityEditText = findViewById(R.id.cityEditText);
        Button getWeatherButton = findViewById(R.id.getWeatherButton);
        temperatureTextView = findViewById(R.id.temperatureTextView);

        getWeatherButton.setOnClickListener(view -> {
            String city = cityEditText.getText().toString();
            getWeatherData(city);
        });
    }

    private void getWeatherData(String city) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        WeatherApiService apiService = retrofit.create(WeatherApiService.class);

        Call<WeatherResponse> call = apiService.getWeatherData(city, API_KEY);

        call.enqueue(new Callback<WeatherResponse>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(@NonNull Call<WeatherResponse> call, @NonNull Response<WeatherResponse> response) {
                if (response.isSuccessful()) {
                    WeatherResponse weatherResponse = response.body();
                    if (weatherResponse != null) {
                        float temperatureFahrenheit = weatherResponse.getMainInfo().getTemperature();
                        float temperatureCelsius = (float) (temperatureFahrenheit - 273.15);
                        long kraj = Math.round(temperatureCelsius);
                        temperatureTextView.setText("Temperatura: " + kraj + "°C");
                    }
                } else {
                    temperatureTextView.setText("Došlo je do problema pri dohvaćanju podataka");
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(@NonNull Call<WeatherResponse> call, @NonNull Throwable t) {
                temperatureTextView.setText("Ne uspiješno dohvaćanje podataka");
            }
        });
    }
}